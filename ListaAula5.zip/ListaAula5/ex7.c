#include <stdio.h>

int main(){
    int n, cont = 1, divisores = 0;
    printf("Informe um n�mero: ");
    scanf("%d", &n);
    do{
        if (n%cont == 0)
            divisores++;
        cont++;
    } while (cont<=n);
    if (divisores == 2)
        printf("\nO %d � primo.", n);
    else
        printf("\nO %d n�o � primo.", n);

    return 0;
}
