#include <stdio.h>

int main()
{
    float salMin, valorVendas, salario;
    int qtdCarros;
    printf("Digite o sal�rio m�nimo: ");
    scanf("%f", &salMin);
    printf("\nDigite o valor total de vendas: ");
    scanf("%f", &valorVendas);
    printf("\nDigite a quantidade de carros vendido: ");
    scanf("%d", &qtdCarros);
    salario = 2 * salMin +  100 * qtdCarros + valorVendas*5/100;
    printf("O sal�rio do funcion�rio � de R$%f reais.",salario);
}
