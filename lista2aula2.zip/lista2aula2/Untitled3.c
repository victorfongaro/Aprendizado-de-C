/* Leia o no. de horas trabalhadas de um oper�rio e calcule o sal�rio sabendo-se que ele ganha R$ 10,00 por hora.
Quando as horas excederem a 50 calcule o excesso de pagamento. A hora excedente de trabalho vale R$ 20,00.
No final do processamento imprimir o sal�rio total e o sal�rio excedente. */

#include <stdio.h>

int main(){
    float horas, sal, salplus;
    salplus = 0;
    printf("Insira as Horas trabalhadas: ");
    scanf("%f", & horas);
    sal = horas * 10;
    if (horas > 50){
        salplus = (horas - 50)*20;
    }
    printf("\nSal�rio total: %f\nSal�rio referente as horas excedentes: %f", sal, salplus);
    return 0;
}
