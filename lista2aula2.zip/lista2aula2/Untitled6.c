/*  prefeitura abriu uma linha de cr�dito para os funcion�rios.
O valor m�ximo da presta��o n�o poder� ultrapassar 30% do sal�rio bruto.
Leia o sal�rio bruto e o valor da presta��o, e informar se o empr�stimo pode ou n�o ser concedid */
#include <stdio.h>

int main(){
    float salBruto, valorPres;
    printf("Escreva o sal�rio bruto: ");
    scanf("%f", & salBruto);
    printf("\nInsira o valor da presta��o: ");
    scanf("%f", &valorPres);
    if  (valorPres <= (0.3*salBruto))
         printf("\nEmprestimo pode ser concedido.");
    else
        printf("\nEmprestimo n�o pode ser concedido.");
    return 0;
}
