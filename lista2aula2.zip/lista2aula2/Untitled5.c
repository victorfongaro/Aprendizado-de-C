#include <stdio.h>
#include <math.h>

int main(){
    float n, numOperacao;
    printf("Escreva um n�mero: ");
    scanf("%f", & n);
    if (n >= 0)
        numOperacao = sqrt(n);
    else
        numOperacao = n * n;
    printf("\nO resultado �: %.2f", numOperacao);
    return 0;
}
